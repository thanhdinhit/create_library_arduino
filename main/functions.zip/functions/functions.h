#ifndef FUNCTIONS_H
#define FUNCTIONS_H

void fun1(int) ;

int fun2(float) ;

#endif